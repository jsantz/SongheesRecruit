<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<circle fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" cx="51" cy="32" r="12"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="0" y1="32" x2="38" y2="32"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="6" y1="32" x2="6" y2="42"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="14" y1="32" x2="14" y2="38"/>
</svg>
