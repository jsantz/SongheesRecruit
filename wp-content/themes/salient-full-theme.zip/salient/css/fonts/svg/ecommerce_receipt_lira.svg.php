<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<g>
	<polygon fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="52,62.999 52,0.999 26,0.999 12,14.999 
		12,63 16,61 20,63 24,61 28,63 32,61 36,63 40,61 44,63 48,61 	"/>
	<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="12,14.999 26,14.999 26,0.999 	"/>
</g>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M39,23c0,0-1.062-1.916-4.941-1.916
	C30.178,21.084,27,22.074,27,26c0,3.927,0,21,0,21h11"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="22" y1="34" x2="34" y2="34"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="22" y1="38" x2="34" y2="38"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="22" y1="47" x2="27" y2="47"/>
</svg>
