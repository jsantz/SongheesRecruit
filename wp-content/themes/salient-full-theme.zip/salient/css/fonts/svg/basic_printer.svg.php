<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<g>
	<rect x="16" y="1" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="32" height="19"/>
	<g>
		<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M16.5,52"/>
	</g>
	<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="16,52 1,52 1,20 63,20 63,52 48,52 	"/>
	<rect x="16" y="39" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="32" height="24"/>
	<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="6" y1="27" x2="10" y2="27"/>
	<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="12" y1="27" x2="16" y2="27"/>
	<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="22" y1="47" x2="42" y2="47"/>
	<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="22" y1="55" x2="42" y2="55"/>
	<g>
		<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M16,52"/>
	</g>
</g>
</svg>
