<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" points="51.083,10 
	42.083,1 33.083,10 "/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="42.083" y1="1" x2="42" y2="55"/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-linejoin="bevel" stroke-miterlimit="10" points="13.083,54 
	22.083,63 31.083,54 "/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="22.083" y1="63" x2="22" y2="9"/>
</svg>
